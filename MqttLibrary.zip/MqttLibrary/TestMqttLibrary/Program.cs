﻿using System;
using System.Threading;

namespace TestMqttLibrary
{
    class Program
    {
        static void Main(string[] args)
        {
            var terminate = new ManualResetEventSlim();
            Console.WriteLine("Hello World!");
            IMqttConnectionManager mqttConnectionManager = new MqttConnectionManager();
            mqttConnectionManager.Initialize("test","localhost",1883,"","");
            mqttConnectionManager.Connect().Wait();
            string topicname = "abcd";
            mqttConnectionManager.SubscribeTopic(topicname,Received);

            Console.ReadLine();
           
            mqttConnectionManager.UnsubscribeTopic(topicname);

            Console.ReadLine();
            mqttConnectionManager.SubscribeTopic(topicname, Received);

            Console.ReadLine();

            mqttConnectionManager.UnsubscribeTopic("abcdddddd");
            terminate.Wait();

        }

        private static void Received(string Message)
        {
            Console.WriteLine(Message);
        }
    }
}
