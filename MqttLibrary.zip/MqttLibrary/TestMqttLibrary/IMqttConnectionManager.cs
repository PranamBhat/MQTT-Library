﻿using System.Threading.Tasks;

namespace TestMqttLibrary
{
    public interface IMqttConnectionManager
    {

        void Initialize(string clientId, string url, int portno, string userName, string Password);
        Task<bool> Connect();
        Task<bool> Disconnect();
        void SubscribeTopic(string topicName, ReceiveMqttMsg callback); 
        void UnsubscribeTopic(string topicName);
        Task<bool> PublishMessage(string topicName, string message,bool retain);
        bool ConnectionStatus();       
    }

    public delegate void ReceiveMqttMsg(string Message);
}