﻿using System;
using MQTTnet;
using MQTTnet.Extensions.ManagedClient;
using MQTTnet.Protocol;
using log4net;
using System.Threading.Tasks;
using System.Collections.Generic;
using MQTTnet.Client;

namespace TestMqttLibrary
{
    class MqttConnectionManager : IMqttConnectionManager
    {

        private readonly ILog _logger = null;
        readonly IManagedMqttClient _mqttClient;
        ManagedMqttClientOptions _managedMqttClientOptionsBuilder;
        bool _isConnected = false;
        readonly Dictionary<string, ReceiveMqttMsg> _dicSubscribedTopics;




        public MqttConnectionManager()
        {
            _logger = LogManager.GetLogger(typeof(MqttConnectionManager));
            _mqttClient = new MqttFactory().CreateManagedMqttClient();
            _dicSubscribedTopics = new Dictionary<string, ReceiveMqttMsg>();
        }

        private void OnApplicationMessageReceived(object sender, MqttApplicationMessageReceivedEventArgs e)
        {
            try
            {
               Console.WriteLine($"Message received From Topic '{e.ApplicationMessage.Topic}' for edge to cloud communication !!!");
                string msg = e.ApplicationMessage.ConvertPayloadToString();

                if (_dicSubscribedTopics.TryGetValue(e.ApplicationMessage.Topic, out ReceiveMqttMsg callback))
                {
                    callback(msg);
                }

            }
            catch (Exception ex)
            {
                _logger.Error("Exception in OnApplicationReceivedMessage" + ex.Message);
            }
        }


        public void Initialize(string clientId, string url, int portno, string userName, string password)
        {
            _logger.Debug($"ClientID={clientId},url={url}, portno={portno}, userName={userName},password={password}");
            _managedMqttClientOptionsBuilder = new ManagedMqttClientOptionsBuilder()
                         .WithClientOptions(
                             new MQTTnet.Client.MqttClientOptionsBuilder()
                                 .WithClientId(clientId)
                                 .WithTcpServer(url, portno)
                                 .WithCredentials(userName, password.Trim())
                                 .WithKeepAlivePeriod(TimeSpan.FromMilliseconds(100))
                                 .WithCleanSession(true)
                                 .Build())
                         .WithAutoReconnectDelay(TimeSpan.FromMilliseconds(100))
                         .Build();

            _mqttClient.ApplicationMessageReceived += OnApplicationMessageReceived;
            _mqttClient.ConnectingFailed += MqttConnectionFailed;
            _mqttClient.Connected += ConnectedWithBrokerCallback;

        }

        public async Task<bool> Connect()
        {
            try
            {
                if ((_managedMqttClientOptionsBuilder != null) && (_mqttClient != null))
                {
                    await _mqttClient.StartAsync(_managedMqttClientOptionsBuilder);
                    _isConnected = true;
                    while (!_mqttClient.IsConnected)
                    {
                        await Task.Delay(5000);
                    }
                   Console.WriteLine("Connected to Mqtt Broker Successfully...");

                    foreach (KeyValuePair<string, ReceiveMqttMsg> keyValuePair in _dicSubscribedTopics)
                    {
                        if (_mqttClient.IsConnected)
                        {
                            await _mqttClient.SubscribeAsync(keyValuePair.Key).ContinueWith((e) =>Console.WriteLine($"Subscribed to MQTT topic '{keyValuePair.Key}' "));
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                _logger.Error("Excpetion occurred while connecting with MQTT broker...");
                _logger.Debug(ex.Message);
                _isConnected = false;
            }
            return _isConnected;
        }

        private void ConnectedWithBrokerCallback(object sender, MqttClientConnectedEventArgs e)
        {
           Console.WriteLine("MQTT Broker connection success ...");
            _isConnected = true;
        }

        private void MqttConnectionFailed(object sender, MqttManagedProcessFailedEventArgs e)
        {
           Console.WriteLine("MQTT Broker connection failed ...");
            _isConnected = false;
        }

        public async Task<bool> Disconnect()
        {
            await _mqttClient.StopAsync();
            _isConnected = false;

            return true;
        }

        public void SubscribeTopic(string topicName, ReceiveMqttMsg callback)
        {

            if (!_dicSubscribedTopics.ContainsKey(topicName))
            {
                _dicSubscribedTopics.Add(topicName, callback);

            }

            if (_mqttClient.IsConnected)
            {
                _mqttClient.SubscribeAsync(topicName).ContinueWith((e) =>Console.WriteLine($"Subscribed to MQTT topic '{topicName}' "));
            }

        }

        public void UnsubscribeTopic(string topicname)
        {
            _mqttClient.UnsubscribeAsync(topicname).Wait();
            Console.WriteLine($"Unsubscribe successfull {topicname}");
        }



        public async Task<bool> PublishMessage(string topicName, string message, bool retain = false)
        {
            bool ret = false;
            if (!_mqttClient.IsConnected)
            {
               Console.WriteLine($"MqttClient is not connected with broker.... ");
                return ret;
            }

            try
            {
                await _mqttClient.PublishAsync(topicName, message, MqttQualityOfServiceLevel.AtLeastOnce, retain: retain);

               Console.WriteLine($"Published message to '{topicName}' ");
                ret = true;
            }
            catch (Exception ex)
            {
                _logger.Error($"Published message failed to '{topicName} ");

                _logger.Debug($"{ex.Message}");
                ret = false;

            }

            return ret;
        }

        public bool ConnectionStatus()
        {
            return _mqttClient.IsConnected;
        }
    }
}
